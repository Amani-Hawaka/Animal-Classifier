import os
from PIL import Image
import tensorflow as tf
import cv2
import matplotlib.pyplot as plt

DATASET_PATH = 'dataset/'
num_classes = len(os.listdir(DATASET_PATH)) #amount of folder-classes
class_mode = "categorical"

def predict_image(image_path):
    if not os.path.exists(image_path):
        print(f"Error: File path is not found: {image_path}")
        return
    try:
        img = Image.open(image_path)
        img.verify() #check for any damage
        img = Image.open(image_path) #Reopening
    except (OSError, IOError):
        print(f"Error: Damaged image - {image_path}")
        return
    model = tf.keras.models.load_model("animal_classifier_v3.h5")
    img = cv2.imread(image_path)
    
    if img is None:
        print(f"Error: Unable to read the image - {image_path}")
        return 
    
    img = cv2.resize(img, (128, 128))
    img = img / 255
    img = tf.expand_dims(img, axis=0)
    
    prediction = model.predict(img)
    class_names = os.listdir(DATASET_PATH)
    predicted_class = class_names[tf.argmax(prediction, axis=-1).numpy()[0]]
    print(f"The model has identified: {predicted_class}")
    img = Image.open(image_path)
    plt.title(f"The model has identified: {predicted_class}")
    plt.imshow(img)
    plt.axis('off')
    plt.show()

predict_image("dataset/snails/snail8.jpg")